package com.appdirect.ExceptionPackage;

public class FileNotFoundException extends Exception
{
	public FileNotFoundException(String s){  
		  super(s);  
		 }  
	

}
