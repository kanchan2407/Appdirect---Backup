package com.appdirect.ExceptionPackage;

public class NoSuchElementException extends Exception 
{
	public NoSuchElementException(String s)
	{
		 super(s);  
	}

}
