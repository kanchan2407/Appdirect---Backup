package com.appdirect.ExceptionPackage;

public class IOException extends Exception{
	public IOException(String s){  
		  super(s);  
		 }  
	

}
