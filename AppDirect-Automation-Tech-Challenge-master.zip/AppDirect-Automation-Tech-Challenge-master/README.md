# AppDirect-Automation-Tech-Challenge

Project Name: Automation Tech-Challenge
Developed By: Kanchan Sharma
Completed on: 13 April 2017

Introduction:

This tech-challenge is based on Java, Selenium Web Driver, Maven and TestNG and will create automated test cases and has the functionality of choosing different browser.

As User will be able to sign up for new account on web site www.appdirect.com by clicking on Login link and then Signup link. Signup page will suggest enter an email address and once it’s entered will send out activation email and if the user enter already registered Email-Id then error message will be display.

This project runs for three browser Chrome,Firefox and Safari. It contains seven packages and five test cases.

Packages::

a.Excpetions
b.Checker
c.Pages
d.Resources	
e.Utils
f.Interface
g.Test

How to Run:

1.In the TestPackage run the AppdirectPageTest.java through TestNG.
2.Run testing.xml directly 
