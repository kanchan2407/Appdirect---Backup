package com.appdirect.ExceptionPackage;

public class NullPointerException extends Exception {
	
	public NullPointerException(String s){
		super(s);
	}
}
